/* NIM/Nama  : 13517137/Vincent Budianto
 * Nama file : Shape.cpp
 * Topik     : Praktikum 5
 * Tanggal   : 21 Februari 2019
 * Deskripsi : Implementasi Shape.cpp */

#include "Shape.hpp"
#include <iostream>

using namespace std;

Shape::~Shape()
{
    cout << "SHAPE DELETED" << endl;
}
