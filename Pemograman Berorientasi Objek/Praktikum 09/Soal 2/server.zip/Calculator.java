/*NIM/Nama   : 13517059/Nixon Andhika
  Nama file  : Calculator.java
  Tanggal    : 28 Maret 2019
  Deskripsi  : kelas Calculator*/

public class Calculator{
	private Server server;

	//public Calculator(){}

	public Server getServer(){
		return server;
	}

	public int addNumber(int a, int b){
		server = new AddServer(a);
		int temp = server.processRequest(b);
		System.out.println("Server returned " + temp);
		return temp;
	}

	public int doubleNumber(int a){
		server = new AddServer();
		int temp = server.processRequest(a);
		System.out.println("Server returned " + temp);
		return temp;
	}

	public int multiplyNumber(int a, int b){
		server = new MultiplyServer(a);
		int temp = server.processRequest(b);
		System.out.println("Server returned " + temp);
		return temp;
	}

	public int squareNumber(int a){
		server = new MultiplyServer();
		int temp = server.processRequest(a);
		System.out.println("Server returned " + temp);
		return temp;
	}
}
