/*NIM/Nama   : 13517059/Nixon Andhika
  Nama file  : AddServer.java
  Tanggal    : 28 Maret 2019
  Deskripsi  : kelas AddServer*/

public class AddServer implements Server{
	private final int constant;
	private static int numAddServerCreated = 0;

	public AddServer(){
		constant = 0;
		numAddServerCreated++;
	}

	public AddServer(int c){
		constant = c;
		numAddServerCreated++;
	}

	public int processRequest(int p){
		int temp = 0;
		if(constant <= 0){
			temp =  p + p;
			System.out.print("Server " + numAddServerCreated + " execute ");
			if(p > 0){
				System.out.println(p + " + " + p);
			} else{
				System.out.println(p + " - " + (-p));
			}
		} else{
			temp = constant + p;
			System.out.print("Server " + numAddServerCreated + " execute " + constant);
			if(p > 0){
				System.out.println(" + " + p);
			} else{
				System.out.println(" - " + (-p));
			}
		}
		return temp;
	}
}
