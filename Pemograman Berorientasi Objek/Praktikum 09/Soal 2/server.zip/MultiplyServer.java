/*NIM/Nama   : 13517059/Nixon Andhika
  Nama file  : MultiplyServer.java
  Tanggal    : 28 Maret 2019
  Deskripsi  : kelas MultiplyServer*/


public class MultiplyServer implements Server{
	private final int constant;
	private static int numMultiplyServerCreated = 0;

	public MultiplyServer(){
		constant = 0;
		numMultiplyServerCreated++;
	}

	public MultiplyServer(int c){
		constant = c;
		numMultiplyServerCreated++;
	}

	public int processRequest(int p){
		int temp = 0;
		if(constant <= 0){
			temp =  p * p;
			System.out.println("Server " + numMultiplyServerCreated + " execute " + p + " * " + p);
		} else{
			temp = constant * p;
			System.out.println("Server " + numMultiplyServerCreated + " execute " + constant + " * " + p);
		}
		return temp;
	}
}
