/*NIM/Nama   : 13517059/Nixon Andhika
  Nama file  : Server.java
  Tanggal    : 28 Maret 2019
  Deskripsi  : interface kelas server*/
  
interface Server{
	public int processRequest(int p);
}
