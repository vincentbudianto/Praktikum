/*NIM/Nama   : 13517059/Nixon Andhika
  Nama file  : RekeningGiro.java
  Tanggal    : 28 Maret 2019
  Deskripsi  : turunan kelas Rekening*/

public class RekeningGiro extends Rekening{
	private boolean penalti = false;

	public RekeningGiro(String n, double s){
		super(n, s, 0.07);
		if(s < 500){
			penalti = true;
		} else{
			penalti = false;
		}
	}

	public void setor(double s){
		saldo += s - 0.1;
		if(saldo < 500){
			penalti = true;
		}
	}

	public void tarik(double s){
		if(saldo >= s + 0.1){
			saldo -= (s + 0.1);
		}
		if(saldo < 500){
			penalti = true;
		}
	}

	public void update(){
		saldo += (this.getSukuBunga() * this.getSaldo()) - this.hitungBiaya();
		if(penalti){
			saldo -= 10;
		}
		if(saldo < 0){
			saldo = 0;
		}
		if(saldo < 500){
			penalti = true;
		} else{
			penalti = false;
		}
	}
}
