/*NIM/Nama   : 13517059/Nixon Andhika
  Nama file  : Rekening.java
  Tanggal    : 28 Maret 2019
  Deskripsi  : Abstract Class Rekening*/

public abstract class Rekening{
	protected String nama;
	protected double saldo;
	protected double sukuBunga;

	public Rekening(String n, double s, double sb){
		nama = n;
		if(s < 0){
			saldo = 0;
		} else{
			saldo = s;
		}
		sukuBunga = sb;
	}

	public abstract void setor(double s);

	public abstract void tarik(double s);

	public abstract void update();

	public double hitungBiaya(){
		double s = 0.1 * this.getSaldo();
		if(s <= 10){
			return s;
		} else{
			return 10;
		}
	}

	public String getNama(){
		return nama;
	}

	public double getSaldo(){
		return saldo;
	}

	public double getSukuBunga(){
		return sukuBunga;
	}
}
