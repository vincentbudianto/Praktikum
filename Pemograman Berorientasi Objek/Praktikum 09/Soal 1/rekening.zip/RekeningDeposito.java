/*NIM/Nama   : 13517059/Nixon Andhika
  Nama file  : RekeningDeposito.java
  Tanggal    : 28 Maret 2019
  Deskripsi  : turunan kelas Rekening*/

public class RekeningDeposito extends Rekening{
	private int bulan;

	public RekeningDeposito(String n, double s){
		super(n, s, 0.15);
		bulan = 0;
	}

	public void setor(double s){
		System.out.println("Tidak dapat melakukan penyetoran uang untuk rekening ini.");
	}

	public void tarik(double s){
		System.out.println("Tidak dapat melakukan penarikan uang sebagian untuk rekening ini.");
	}

	public void update(){
		bulan++;
		if(bulan >= 12 && bulan % 12 == 0){
			saldo += (this.getSaldo() * this.getSukuBunga());
		}
		saldo -= this.hitungBiaya();
		if(saldo < 0){
			saldo = 0;
		}
	}

	public void tarik(){
		if(bulan < 12){
			double p = 0.2 * this.getSaldo();
			System.out.println("Anda terkena penalti sebesar " + p + ".");
		}
		saldo = 0;
	}
}
