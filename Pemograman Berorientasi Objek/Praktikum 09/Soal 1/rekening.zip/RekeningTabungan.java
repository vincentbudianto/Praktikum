/*NIM/Nama   : 13517059/Nixon Andhika
  Nama file  : RekeningTabungan.java
  Tanggal    : 28 Maret 2019
  Deskripsi  : turunan kelas Rekening*/

public class RekeningTabungan extends Rekening{
	public RekeningTabungan(String n, double s){
		super(n, s, 0.05);
	}

	public void setor(double s){
		saldo += s;
	}

	public void tarik(double s){
		if(saldo >= s){
			saldo -= s;
		}
	}

	public void update(){
		saldo += (this.getSukuBunga() * this.getSaldo()) - this.hitungBiaya();
		if(saldo < 0){
			saldo = 0;
		}
	}
}
