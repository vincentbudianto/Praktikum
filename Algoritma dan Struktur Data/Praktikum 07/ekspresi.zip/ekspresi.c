/* NIM/Nama  : 13517137/Vincent Budianto
 * Nama file : ekspresi.c
 * Topik     : Praktikum 07
 * Tanggal   : 18 October 2018
 * Deskripsi : Driver ADT STACKT Dan MESINTOKEN */

#include <stdio.h>
#include <math.h>
#include "stackt.h"
#include "mesinkar.h"
#include "mesintoken.h"

int main()
{
	//KAMUS
	int a;
	int b;
	
	//ALGORITMA
	STARTTOKEN();
	if (EndToken)
	{
		printf("Ekspresi kosong\n");
	}
	else
	{
		a = CToken.val;
		printf("%d\n", a);
		while (!EndToken)
		{
			if (CToken.tkn != 'b')
			{
				printf("%d %c %d\n", a, CToken.tkn, b);
				if (CToken.tkn == '+')
				{
					a = a + b;
				}
				else if (CToken.tkn == '-')
				{
					a = a - b;
				}
				else if (CToken.tkn == '*')
				{
					a = a * b;
				}
				else if (CToken.tkn == '/')
				{
					a = a / b;
				}
				else if (CToken.tkn == '^')
				{
					a = pow(a, b);
				}
				printf("%d\n", a);
			}
			else
			{
				b = CToken.val;
				printf("%d\n", b);
			}
			ADVTOKEN();
		}
	}
	return 0;
}

